# The function that builds and runs A1F-001 for landlab at grid level dx20.
# It comes from run_landlab.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def macdonald_1d(m: dict, dx: float, tid: str) -> dict:
    from references.macdonald import M1_PARAMS, bed_elevation, depth_profile

    L, B, Q, n = (float(M1_PARAMS[k]) for k in ("L", "B", "Q", "n_manning"))
    fine = np.linspace(0.0, L, 200001)
    zfine = bed_elevation(fine)  # beyond the ends (the boundary nodes) the bed is held level
    s = Strip(0.0, L, dx)
    s.walls(east_open=True)
    s.z[:] = np.interp(s.g.x_of_node, fine, zfine)
    h_out = float(depth_profile(np.array([L]))[0])
    s.h[:] = h_out
    t = s.run(float(m["simulation"]["t_end"]), n=n, q_in=Q / B, h_out=h_out)
    return _one_d(s, t)
