# The function that builds and runs A1F-043 for landlab at grid level dx0.05.
# It comes from run_landlab.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def swashes_bump(m: dict, dx: float, tid: str) -> dict:
    from references.swashes import bed

    p = json.loads((Path(m["_case_dir"]) / "inputs/params.json").read_text())
    L = p["domain"]["xmax"]
    up, down = p["upstream"], p["downstream"]
    s = Strip(0.0, L, dx)
    s.walls(east_open="depth_m" in down)
    s.z[:] = bed(np.clip(s.g.x_of_node, 0.0, L))
    s.h[:] = np.maximum(p["initial"]["level_m"] - s.z, 0.0)
    s.h[s.g.boundary_nodes] = 0.0
    t = s.run(float(m["simulation"]["t_end"]), q_in=up.get("discharge_m2s"), h_out=down.get("depth_m"))
    return _one_d(s, t)
