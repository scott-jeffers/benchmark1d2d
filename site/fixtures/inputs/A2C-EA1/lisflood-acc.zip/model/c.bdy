Benchmark1d2d boundary series
west
6 seconds
9.7 0
9.7 300
10.35 3600
10.35 39600
9.7 43200
9.7 72000
