# The function that builds and runs A1F-010 for landlab at grid level dx1.25.
# It comes from run_landlab.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def dam_break(m: dict, dx: float, tid: str) -> dict:
    p = json.loads((Path(m["_case_dir"]) / "inputs/params.json").read_text())
    dom, ic = p["domain"], p["initial_condition"]
    s = Strip(dom["xmin"], dom["xmax"], dx)
    s.walls()
    s.h[:] = np.where(s.g.x_of_node < ic["dam_x_m"], ic["h_left_m"], ic["h_right_m"])
    s.h[s.g.boundary_nodes] = 0.0
    t = s.run(float(m["simulation"]["t_end"]))
    return _one_d(s, t)
