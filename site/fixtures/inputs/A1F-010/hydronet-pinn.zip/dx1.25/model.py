# The function that builds and runs A1F-010 for hydronet-pinn at grid level dx1.25.
# It comes from run_hydronet.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def run_pinn(mesh, h0, u0, v0, wse_still, t_end, epochs: int, workdir: Path):
    import torch

    from HydroNet import Config, FVM_PINNDataset, FVM_PINNTrainer, FVM_SWE_PINN

    np.random.seed(123456)
    torch.manual_seed(123456)  # as HydroNet's example
    cfg = workdir / "fvm_pinn_config.yaml"
    cfg.write_text(PINN_CONFIG.format(wse_still=wse_still, h_dry=H_DRY, t_end=t_end, epochs=epochs,
                                      ckpt=str(workdir / "checkpoints")), encoding="utf-8")
    config = Config(str(cfg))
    n = mesh.n_cells
    xc, yc = mesh.cell_center[:, 0], mesh.cell_center[:, 1]
    model = FVM_SWE_PINN(config)
    bed = np.asarray(mesh.bed_elev, float)
    h_still = np.maximum(wse_still - bed, 0.0)
    ic = {"xyt": torch.column_stack([torch.tensor(xc), torch.tensor(yc), torch.zeros(n, dtype=torch.float64)]),
          "U_true": torch.stack([torch.tensor(h0 - h_still), torch.tensor(h0 * u0), torch.tensor(h0 * v0)], dim=-1)}
    dataset = FVM_PINNDataset.from_mesh(config, mesh, ic_data=ic)
    trainer = FVM_PINNTrainer(model, dataset, config)
    trainer.train()
    xyt = torch.column_stack([torch.tensor(xc), torch.tensor(yc), torch.full((n,), t_end, dtype=torch.float64)])
    with torch.no_grad():
        q = model(xyt.to(model.get_device())).cpu().numpy()
    h = np.maximum(q[:, 0], 0.0)
    return h, np.where(h > H_DRY, q[:, 1], 0.0), np.where(h > H_DRY, q[:, 2], 0.0)
