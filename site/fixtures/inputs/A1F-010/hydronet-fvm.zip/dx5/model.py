# The function that builds and runs A1F-010 for hydronet-fvm at grid level dx5.
# It comes from run_hydronet.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def run_fvm(mesh, h0, u0, v0, wse_still, t_end):
    import torch

    from HydroNet.models.FVM_PINN._internal.fvm import compute_cell_geometry as ccg
    from HydroNet.models.FVM_PINN._internal.fvm import run_fvm_rk2

    md = ccg(mesh, device="cpu")
    bed = md["bed_elev"]
    h_still = (wse_still - bed).clamp(min=0.0).to(torch.float64)
    md["h_still"] = h_still
    md["bc_ghost"] = {}
    h0t = torch.tensor(h0, dtype=torch.float64)
    Q0 = torch.stack([h0t - h_still, h0t * torch.tensor(u0), h0t * torch.tensor(v0)], dim=-1)
    cfl, h_dry = SET.get("cfl", CFL), SET.get("h_dry", H_DRY)  # a proposed set-up may change them (BENCH_SETUP)
    _, Q = run_fvm_rk2(Q0, md, h_still, [0.0, t_end], cfl=cfl, h_dry=h_dry)
    q = Q[-1].numpy()
    h = np.maximum(q[:, 0] + h_still.numpy(), 0.0)
    wet = h > h_dry
    u = np.where(wet, q[:, 1] / np.where(wet, h, 1.0), 0.0)
    v = np.where(wet, q[:, 2] / np.where(wet, h, 1.0), 0.0)
    return h, u, v
