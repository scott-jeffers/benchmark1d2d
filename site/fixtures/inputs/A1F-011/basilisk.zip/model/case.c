#include "grid/cartesian1D.h"
#include "saint-venant.h"
int main (int argc, char * argv[]) { size (2000); origin (-1000); G = 9.81; init_grid (atoi (argv[1])); run(); }
event init (i = 0) { foreach() { zb[] = 0.; h[] = x < 0 ? 1 : 0.1; u.x[] = 0.; } }
event end (t = 30) { foreach() printf ("%.12g %.12g %.12g %.12g\n", x, h[], u.x[], zb[]); }
