# The function that builds and runs A2A-010 for landlab at grid level dx6.25.
# It comes from run_landlab.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def macdonald_2d(m: dict, dx: float, tid: str) -> dict:
    from references.macdonald_2d import bed_elevation, depth_profile

    prm = m["reference"]["generator"]["parameters"]
    L, W, q, n = prm["L"], prm["W"], prm["q"], prm["n_manning"]
    s = Strip(0.0, L, dx, 0.0, W)
    s.walls(east_open=True)
    s.z[:] = bed_elevation(np.clip(s.g.x_of_node, 0.0, L + dx), L=L, q=q, n_manning=n)
    h_out = float(depth_profile(L))
    s.h[:] = h_out
    t = s.run(float(m["simulation"]["t_end"]), n=n, q_in=q, h_out=h_out)
    return _two_d(s, t)
