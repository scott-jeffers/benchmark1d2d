#include "grid/multigrid.h"
#include "saint-venant.h"
h[left] = dirichlet (1); eta[left] = dirichlet (1); u.n[left] = dirichlet (7.5634212685); u.t[left] = dirichlet (-2.02661262091);
h[top] = dirichlet (1); eta[top] = dirichlet (1); u.n[top] = dirichlet (-2.02661262091); u.t[top] = dirichlet (7.5634212685);
h[right] = neumann (0.); eta[right] = neumann (0.); u.n[right] = neumann (0.); u.t[right] = neumann (0.);
int main (int argc, char * argv[]) { dimensions (nx = atoi (argv[2]), ny = atoi (argv[3])); size (40); origin (0, 0); G = 9.81; init_grid (atoi (argv[1])); run(); }
event init (i = 0) { foreach() { zb[] = 0.; h[] = 1; u.x[] = 7.5634212685; u.y[] = -2.02661262091; } }
event end (t = 50) { foreach() printf ("%.12g %.12g %.12g %.12g %.12g %.12g\n", x, y, h[], u.x[], u.y[], zb[]); }
