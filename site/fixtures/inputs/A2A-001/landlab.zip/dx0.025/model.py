# The function that builds and runs A2A-001 for landlab at grid level dx0.025.
# It comes from run_landlab.py (copied beside this file), which is run with the test's manifest;
# see README in the test's download for the exact command.

def thacker(m: dict, dx: float, tid: str) -> dict:
    from references.thacker import bed_elevation, depth_velocity

    prm = m["reference"]["generator"]["parameters"]
    dom = json.loads((Path(m["_case_dir"]) / "inputs/params.json").read_text())["domain"]
    s = Strip(dom["xmin"], dom["xmax"], dx, dom["ymin"], dom["ymax"])
    s.walls()
    x, y = s.g.x_of_node, s.g.y_of_node
    s.z[:] = bed_elevation(x, y, prm["h0"], prm["L"])
    s.h[:] = np.maximum(depth_velocity(x, y, 0.0, h0=prm["h0"], L=prm["L"], eta=prm["eta"], g=prm.get("g", 9.81))["h"], 0.0)
    s.h[s.g.boundary_nodes] = 0.0
    t = s.run(float(m["simulation"]["t_end"]))
    return _two_d(s, t)
