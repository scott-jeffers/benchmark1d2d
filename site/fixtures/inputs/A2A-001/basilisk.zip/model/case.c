#include "grid/multigrid.h"
#include "saint-venant.h"
int main (int argc, char * argv[]) { dimensions (nx = atoi (argv[2]), ny = atoi (argv[2])); size (2.2); origin (-1.1, -1.1); G = 9.81; init_grid (atoi (argv[1])); run(); }
event init (i = 0) { foreach() { zb[] = 0.1*((sq(x) + sq(y))/1 - 1.); h[] = max (0.005*(2.*x - 0.05) - zb[], 0.); u.x[] = u.y[] = 0.; } }
event end (t = 1) { foreach() printf ("%.12g %.12g %.12g %.12g %.12g %.12g\n", x, y, h[], u.x[], u.y[], zb[]); }
