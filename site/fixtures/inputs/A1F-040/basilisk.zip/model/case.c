#include "grid/cartesian1D.h"
#include "saint-venant.h"
u.n[left] = dirichlet (4.42/max (h[], 1e-6));
h[right] = dirichlet (2); eta[right] = dirichlet (2); u.n[right] = neumann (0.);
int main (int argc, char * argv[]) { size (25); origin (0); G = 9.81; init_grid (atoi (argv[1])); run(); }
event init (i = 0) { foreach() { zb[] = (x > 8. && x < 12.) ? 0.2 - 0.05*sq(x - 10.) : 0.; h[] = max (2 - zb[], 0.); u.x[] = 0.; } }
event end (t = 300) { foreach() printf ("%.12g %.12g %.12g %.12g\n", x, h[], u.x[], zb[]); }
