#include "grid/cartesian1D.h"
#include "saint-venant.h"
h[left] = dirichlet (0.2); eta[left] = dirichlet (0.2); u.n[left] = dirichlet (3.50178525898);
h[right] = dirichlet (0.614142842854); eta[right] = dirichlet (0.614142842854); u.n[right] = neumann (0.);
int main (int argc, char * argv[]) { size (100); origin (0); G = 9.81; init_grid (atoi (argv[1])); run(); }
event init (i = 0) { foreach() { zb[] = 0.; h[] = x < 50 ? 0.2 : 0.614142842854; u.x[] = 0.700357051796/h[]; } }
event end (t = 200) { foreach() printf ("%.12g %.12g %.12g %.12g\n", x, h[], u.x[], zb[]); }
